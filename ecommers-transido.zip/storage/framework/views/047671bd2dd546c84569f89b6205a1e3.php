
<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Data Produk</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="#">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="/merchant/produk">Produk </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-Produk">
                    <h4 class="card-title">Data Produk</h4>
                    <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary btn-round ml-auto">
                        <i class="fa fa-plus"></i>
                        Tambah Produk
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="display table table-striped table-hover data-table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>nama</th>
                                <th>Image</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Qty</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td> <?php echo e($item->name); ?>

                                    </td>
                                    <td><img src="<?php echo e(asset('produk/' . $item->image)); ?>"
                                        style="width: 100px; height: 100px; object-fit: cover" alt=""></td>
                                    <td> <?php echo e($item->kategori->name); ?>

                                    </td>
                                    <td> <?php echo e($item->harga); ?>

                                    </td>
                                    <td> <?php echo e($item->qty); ?>

                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('produk.destroy', $item->id)); ?>" method="post">

                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <a href="<?php echo e(route('produk.edit', $item->id)); ?>"
                                                class="btn btn-warning btn-sm">edit</a>
                                            <button class="btn btn-danger btn-sm" data-toggle="tooltip" id="delete"
                                                title="Remove" type="submit">hapus</button>

                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.2.4\htdocs\laravel\ecommers-transido\resources\views/merchant/produk/index.blade.php ENDPATH**/ ?>