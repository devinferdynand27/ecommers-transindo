Aplikasi Ecommers 

https://fitstyle.icommits.co.id/

roles 
 - merchant
 - custumer

    Akun :
    . merchant
    - email :  admin@gmail.com
    - password : admin@gmail.com
  
    - member (bisa daftar sendiri di pendaftarn custumer )
   Noted : Jika belum login maka tidak bisa chekout 
